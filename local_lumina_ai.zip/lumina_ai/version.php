<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Lumina AI - Standalone AI Academic Tutor Plugin for Moodle
 *
 * Works on ANY Moodle theme (Boost, Lumina, Classic, etc.)
 * via Moodle hook system. Safe from core updates.
 *
 * @package    local_lumina_ai
 * @copyright  2026 Lumina LMS
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_lumina_ai';
$plugin->version   = 2026110500;
$plugin->requires  = 2023100900; // Moodle 4.3+ (hooks system)
$plugin->release   = '1.0.0';
$plugin->maturity  = MATURITY_STABLE;

